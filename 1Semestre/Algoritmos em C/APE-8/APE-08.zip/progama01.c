/*Escreva um programa modularizado em linguagem C que apenas imprima o seu nome
completo utilizando uma função. Basta que a função main inicie chamando uma outra
função que apenas imprima seu nome no vídeo.
*/
#include<stdio.h> 
void mostra_nome (){
    printf("Breno de Melo");
}
int main(){
   mostra_nome();
    return 0;
}

