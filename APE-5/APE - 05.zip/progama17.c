/*Escreva um programa em linguagem C que imprima todos os números inteiros desde 1 até
20 na tela utilizando a estrutura while.
*/
#include<stdio.h>
int main() {
    int i =1;
    while(i<=20){
        printf("%d\n", i);
        i++;
    };
    return 0;
}