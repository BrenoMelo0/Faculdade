/*Escreva um algoritmo na linguagem de pseudocódigo Portugol que imprima uma palavra
qualquer 20 vezes na tela utilizando a estrutura faça-enquanto (variação da estrutura repitaaté).
*/

algoritmo "ImprimirPalavra20Vezes_FacaEnquanto"

variáveis
    contador: inteiro

início
    contador <- 1

    faça
        escreva("Olá", "\n")
        contador <- contador + 1
    enquanto contador <= 20

fimalgoritmo