/* Escreva um algoritmo na linguagem de pseudocódigo Portugol que imprima uma palavra
qualquer 20 vezes na tela utilizando a estrutura para-fimpara.*/

algoritmo "ImprimirPalavra20Vezes_Para"

variáveis
    i: inteiro

início
    para i de 1 até 20 faça
        escreva("Olá", "\n")
    fimpara

fimalgoritmo