/*Escreva um algoritmo na linguagem de pseudocódigo Portugol que imprima uma palavra
qualquer 20 vezes na tela utilizando a estrutura enquanto-fimenquanto.
*/

algoritmo "ImprimirPalavra20Vezes"

variáveis
    contador: inteiro

início
    contador <- 1

    enquanto contador <= 20 faça
        escreva("Olá", "\n")
        contador <- contador + 1
    fimenquanto

fimalgoritmo