/*Escreva um programa em linguagem C que imprima todos os números inteiros desde 1 até
20 na tela utilizando a estrutura for.
*/
#include<stdio.h>
int main() {
    
    for (int i = 1; i <= 20; i++) {
        printf("%d\n", i);
    }
    
    return 0;
}