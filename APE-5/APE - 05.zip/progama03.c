/*Escreva um programa em linguagem C que imprima uma palavra qualquer 20 vezes na tela
utilizando a estrutura for.*/
#include<stdio.h>
int main() {
    
    for (int i = 1; i <= 20; i++) {
        printf("%d - ola\n", i);
    }
    
    return 0;
}