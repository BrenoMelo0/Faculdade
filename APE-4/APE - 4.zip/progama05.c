/*Nao é possivel escrever o progama solicitado com switch pois o mesmo apenas compara equivalencia mas nao pode comparar com intervalos*/

